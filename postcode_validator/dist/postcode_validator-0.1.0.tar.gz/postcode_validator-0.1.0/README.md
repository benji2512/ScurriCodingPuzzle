# postcode-validator

A library to validate United Kingdom(UK) postcodes. These are mailing addresses that follow a scrict format that this library will help in reducing false and incorrect postcodes.
