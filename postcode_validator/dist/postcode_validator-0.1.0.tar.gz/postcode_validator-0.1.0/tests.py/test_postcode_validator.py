from postcode_validator import postcode_validator

def test_valid_postcode():
  # Just print the postcode
  assert postcode_validator.pc_validate("M1 1AE") == True

def test_short_invalid_postcode():
  # Just print the postcode
  assert postcode_validator.pc_validate("B 8TH") == False

def test_no_space_invalid_postcode():
  # Just print the postcode
  assert postcode_validator.pc_validate("DN551PT") == False
