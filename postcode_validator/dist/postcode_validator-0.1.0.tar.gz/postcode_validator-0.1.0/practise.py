from postcode_validator import postcode_validator

print(postcode_validator.pc_validate("M1 1AE"))
